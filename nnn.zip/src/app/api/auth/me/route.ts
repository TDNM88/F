import { NextResponse } from 'next/server';
import { getMongoDb } from '@/lib/db';

export async function GET(request: Request) {
  try {
    // Lấy token từ cookie
    const cookies = request.headers.get('cookie') || '';
    const tokenMatch = cookies.match(/token=([^;]+)/);
    
    if (!tokenMatch) {
      return NextResponse.json(
        { success: false, message: 'Chưa đăng nhập' },
        { status: 401 }
      );
    }

    const token = tokenMatch[1];
    
    // Lấy user ID từ token (định dạng: user_<user_id>_<timestamp>)
    const userIdMatch = token.match(/^user_([^_]+)_/);
    
    if (!userIdMatch) {
      return NextResponse.json(
        { success: false, message: 'Token không hợp lệ' },
        { status: 401 }
      );
    }

    const userId = userIdMatch[1];
    
    // Lấy thông tin user từ database
    const db = await getMongoDb();
    if (!db) {
      throw new Error('Không thể kết nối cơ sở dữ liệu');
    }
    
    // Sử dụng userId trực tiếp vì chúng ta đang lưu _id dạng string
    const user = await db.collection('users').findOne(
      { _id: userId as any },
      { projection: { password: 0 } } // Không trả về mật khẩu
    );

    console.log('Found user:', user ? 'Yes' : 'No');

    if (!user) {
      return NextResponse.json(
        { success: false, message: 'User not found' },
        { status: 404, headers: { 'Cache-Control': 'no-store' } }
      );
    }

    const userResponse = {
      ...user,
      _id: user._id.toString(),
      id: user._id.toString(), // Ensure both _id and id are available
      role: user.role || 'user',
      isAdmin: user.role === 'admin'
    };
    
    console.log('Returning user data:', userResponse);
    
    return new NextResponse(
      JSON.stringify({
        success: true,
        user: userResponse
      }),
      {
        status: 200,
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-store, max-age=0',
        },
      }
    );

  } catch (error) {
    console.error('Auth me error:', error);
    return NextResponse.json(
      { success: false, message: 'Internal server error' },
      { status: 500 }
    );
  }
}
