import { NextResponse } from 'next/server';

export async function POST() {
  try {
    // Tạo response mới
    const response = NextResponse.json({
      success: true,
      message: 'Đăng xuất thành công'
    });

    // Xóa cookie token
    response.cookies.set('token', '', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      maxAge: 0 // Xóa cookie ngay lập tức
    });

    return response;
  } catch (error) {
    console.error('Lỗi đăng xuất:', error);
    return NextResponse.json(
      { success: false, message: 'Lỗi hệ thống' },
      { status: 500 }
    );
  }
}

export { POST as GET };
