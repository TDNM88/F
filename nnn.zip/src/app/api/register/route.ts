import { NextResponse } from 'next/server';
import { getMongoDb } from '@/lib/db';
import { hashPassword } from '@/lib/auth';

export async function POST(request: Request) {
  try {
    const { username, password, email, fullName } = await request.json();
    
    // Validate input
    if (!username || !password || !email) {
      return NextResponse.json(
        { success: false, message: 'Vui lòng nhập đầy đủ thông tin' },
        { status: 400 }
      );
    }

    // Kiểm tra định dạng email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { success: false, message: 'Email không hợp lệ' },
        { status: 400 }
      );
    }

    // Kiểm tra độ dài mật khẩu
    if (password.length < 6) {
      return NextResponse.json(
        { success: false, message: 'Mật khẩu phải có ít nhất 6 ký tự' },
        { status: 400 }
      );
    }

    const db = await getMongoDb();
    if (!db) {
      throw new Error('Không thể kết nối cơ sở dữ liệu');
    }
    
    // Kiểm tra username đã tồn tại chưa
    const existingUser = await db.collection('users').findOne({ 
      $or: [
        { username },
        { email }
      ]
    });

    if (existingUser) {
      const message = existingUser.username === username 
        ? 'Tên đăng nhập đã được sử dụng' 
        : 'Email đã được đăng ký';
      
      return NextResponse.json(
        { success: false, message },
        { status: 400 }
      );
    }
    
    // Mã hóa mật khẩu
    const hashedPassword = await hashPassword(password);
    
    // Tạo user mới
    const now = new Date();
    const result = await db.collection('users').insertOne({
      username,
      email,
      password: hashedPassword,
      fullName: fullName?.trim() || '',
      role: 'user',
      balance: 0, // Số dư ban đầu
      createdAt: now,
      updatedAt: now
    });
    
    if (!result.insertedId) {
      throw new Error('Không thể tạo tài khoản');
    }
    
    return NextResponse.json({
      success: true,
      message: 'Đăng ký thành công!',
      userId: result.insertedId
    });
    
  } catch (error) {
    console.error('Lỗi đăng ký:', error);
    return NextResponse.json(
      { success: false, message: 'Lỗi hệ thống' },
      { status: 500 }
    );
  }
}
